@if($caja_abierta == null)
<div class="row layout-top-spacing">
	<div class="col-sm-12 col-md-12">        
        <!-- Modal -->
       <?php /* 
	    @include('livewire.pos.partials.modal-email') 
        @include('livewire.pos.partials.modal-formulario')
		*/ ?>
        @include('livewire.pos.partials.modal-abrir-caja')        

@else
<div>
	<div class="row layout-top-spacing">
		<div class="col-sm-12 col-md-12">
		<?php /**/?> 
		@include('livewire.pos.partials.modal-email')
            @include('livewire.pos.partials.modal-formulario')
			<?php /**/?>			
             @include('livewire.pos.partials.header') 
	</div>
    <div class="col-sm-12 col-md-12">
         @include('livewire.pos.partials.barra-busqueda')
	</div>


<div class="col-sm-12 col-md-8">
	<!-- DETALLES -->
	<button hidden type="button" name="button" wire:click="enviarNotificacion()">Notificacion</button>
    @include('livewire.pos.partials.detail')
</div>
    <div class="col-sm-12 col-md-4">
        <!-- TOTAL -->
        @include('livewire.pos.partials.total')
        <!-- DENOMINATIONS
                @include('livewire.pos.partials.coins')
    -->

    </div>
</div>
		<?php /*
		@include('livewire.pos.form-hoja-ruta')
		@include('livewire.pos.datos-cliente')
		@include('livewire.pos.form-hoja-ruta-nueva')
		@include('livewire.factura.form-pagos')
		@include('livewire.pos.agregar-pago')
		
		@include('livewire.pos.partials.comentarios')
	
		@include('livewire.pos.pago-dividido')
		*/?>
		@include('livewire.pos.partials.modal-pago-dividido')
		@include('livewire.pos.cheque')
		
		<?php /*
		@include('livewire.reports.sales-detail2')
		@include('livewire.reports.sales-detail3')
		
		@include('livewire.pos.partials.form-alto')
		*/
		?>
		@include('livewire.pos.estado-pedido-pos')
		
	
		<!-- @include('livewire.pos.form') -->		
		<!--Add Lucas -->
		<!-- Buscador de productos-->
		@include('livewire.pos.form-products')
		
		@include('livewire.pos.form-banco')
		@include('livewire.pos.form-metodo-pago')

		<?php /*
		@include('livewire.pos.partials.imprimir')


		@include('livewire.pos.ver-factura')
		
		@include('livewire.pos.info')
		
		@include('livewire.pos.partials.modal-info-product')
		*/?>
		@include('livewire.pos.variaciones')

	</div>




@endif

<input type="hidden" id="completo_formulario" value="{{$completa_formulario->completo_formulario}}" >

<script src="{{ asset('js/keypress.js') }}"></script>
<script src="{{ asset('js/onscan.js') }}"></script>
<script>

try{

    onScan.attachTo(document, {
    suffixKeyCodes: [13],
    onScan: function(barcode) {
        console.log(barcode)
        window.livewire.emit('scan-code', barcode)
    },
    onScanError: function(e){
        //console.log(e)
    }
})

    console.log('Scanner ready!')


} catch(e){
    console.log('Error de lectura: ', e)
}


</script>
<script>
    document.addEventListener('DOMContentLoaded', function(){
            livewire.on('scan-code', action => {
                $('#code').val('')
            })

						window.livewire.on('modal-formulario', Msg => {
							$('#ModalFormulario').modal('show')
							document.getElementById('ModalFormulario').style.display = 'block';

						})

						window.livewire.on('cliente-agregado', Msg => {
								$('#theModal-cliente').modal('hide')
								noty(Msg)
						})

								window.livewire.on('agregar-cliente', Msg => {
										$('#theModal-cliente').modal('show')
								})
								
								window.livewire.on('datos-cliente', Msg => {
										$('#datos-cliente').modal('show')
								})
								
								window.livewire.on('datos-cliente-hide', Msg => {
										$('#datos-cliente').modal('hide')
								})


								window.livewire.on('variacion-elegir', Msg => {
										$('#Variaciones').modal('show')
								})

								window.livewire.on('variacion-elegir-hide', Msg => {
										$('#Variaciones').modal('hide')
								})

								window.livewire.on('formulario', Msg => {
									$('#ModalFormulario').modal('show');
									document.getElementById('ModalFormulario').style.display = 'block';
								})

								window.livewire.on('formulario-hide', Msg => {
										$('#ModalFormulario').modal('hide');
										document.getElementById('ModalFormulario').style.display = 'none';
										noty(Msg);
								})

								window.livewire.on('agregar-pago', Msg =>{
										$('#AgregarPago').modal('show')
								})

								window.livewire.on('agregar-pago-hide', Msg =>{
										$('#AgregarPago').modal('hide')
								})

								window.livewire.on('show-modal', Msg =>{
										$('#modalDetails').modal('show')
								})

								window.livewire.on('show-modal-alto', Msg =>{
										$('#modalDetailsAlto').modal('show')
								})

								window.livewire.on('show-modal2', Msg =>{
										$('#modalDetails2').modal('show')
								})

								window.livewire.on('pago-dividido', Msg =>{
										$('#PagoDividido').modal('show')
								})

								window.livewire.on('pago-dividido-hide', Msg =>{
										$('#PagoDividido').modal('hide')
								})

								window.livewire.on('cheque', Msg =>{
										$('#Cheque').modal('show')
								})

								window.livewire.on('cheque-hide', Msg =>{
										$('#Cheque').modal('hide')
								})

								window.livewire.on('tipo-pago-nuevo-show', Msg =>{
										$('#ModalBanco').modal('show')
								})

								window.livewire.on('tipo-pago-nuevo-hide', Msg =>{
										$('#ModalBanco').modal('hide')
								})

								window.livewire.on('metodo-pago-nuevo-show', Msg =>{
										$('#ModalMetodoPago').modal('show')
								})

								window.livewire.on('metodo-pago-nuevo-hide', Msg =>{
										$('#ModalMetodoPago').modal('hide')
								})

								window.livewire.on('hide-modal2', Msg =>{
										$('#modalDetails2').modal('hide')
								})

								window.livewire.on('cerrar-factura', Msg =>{
										$('#theModal1').modal('hide')
								})

								window.livewire.on('modal-show', msg => {
									$('#theModal1').modal('show')
								})

								window.livewire.on('abrir-hr-nueva', msg => {
									$('#theModal').modal('show')
								})

								window.livewire.on('show-modal3', Msg =>{
										$('#modalDetails3').modal('show')
								})

								window.livewire.on('hide-modal3', Msg =>{
										$('#modalDetails3').modal('hide')
								})

								window.livewire.on('modal-hr-hide', Msg =>{
										$('#theModal').modal('hide')
								})

								window.livewire.on('productos-hide', Msg =>{
										$('#ModalProductos').modal('hide')
								})

								window.livewire.on('metodo-pago-hide', Msg =>{
										$('#ModalMetodoPago').modal('hide')
								})

								window.livewire.on('cliente-hide', Msg =>{
										$('#ModalCliente').modal('hide')
								})

								window.livewire.on('banco-hide', Msg =>{
										$('#ModalBanco').modal('hide')
								})

								window.livewire.on('info-prod', Msg =>{
										$('#InfoProducto').modal('show')
								})

								window.livewire.on('hide-info-prod', Msg =>{
										$('#InfoProducto').modal('hide')
								})


								window.livewire.on('hr-added', Msg => {
									noty(Msg)
								})

								window.livewire.on('modal-estado', Msg =>{
										$('#modalDetails-estado-pedido').modal('show')

								})

								window.livewire.on('modal-estado-hide', Msg =>{
										$('#modalDetails-estado-pedido').modal('hide')
								})

								window.livewire.on('hr-asignada', Msg => {
									noty(Msg)
								})

								window.livewire.on('pago-agregado', Msg => {
									noty(Msg)
								})

								window.livewire.on('pago-actualizado', Msg => {
									noty(Msg)
								})

                                window.livewire.on('mail-modal', Msg =>{
                                $('#modalImprimir').modal('hide')
                                $('#MailModal').modal('show')
                                })


								window.livewire.on('pago-eliminado', Msg => {
									noty(Msg)
								})




								window.livewire.on('buscar-stock', id => {
									swal({
										title: 'BUSCAR STOCK EN OTRA SUCURSAL',
										text: '¿DESEA BUSCAR EN OTRAS SUCURSALES ESTE PRODUCTO?',
										showCancelButton: true,
										cancelButtonText: 'Cerrar',
										cancelButtonColor: '#fff',
										confirmButtonColor: '#3B3F5C',
										confirmButtonText: 'Aceptar'
									}).then(function(result) {
										if (result.value) {
											window.livewire.emit('info-producto', id)
											swal.close()
										}

									})

								})


								window.livewire.on('volver-stock', id => {
								var stock = $("#q"+id).val();
								$("#r"+id).val(stock);
								})

								window.livewire.on('no-stock', Msg => {
									noty(Msg, 2)
								})



								window.livewire.on('imprimir-show', Msg => {
									$('#modalImprimir').modal('show')
								})

    			    	window.livewire.on('no-factura', id => {
                swal({
                title: 'IMPORTATE',
                text: 'DEBE CONFIGURAR SUS DATOS FISCALES ANTES DE FACTURAR',
                showCancelButton: true,
                cancelButtonText: 'CERRAR',
                cancelButtonColor: '#fff',
                confirmButtonColor: '#3B3F5C',
                confirmButtonText: 'IR A CONFIGURAR'
                }).then(function(result) {
                if (result.value) {
                window.location.href = '/mi-comercio';
                swal.close()
                }

                })

                })





								window.livewire.on('mensaje-facturar', id => {
									swal({
										title: 'FACTURAR',
										text: '¿DESEA EMITIR LA FACTURA DE AFIP?',
										showCancelButton: true,
										cancelButtonText: 'Cerrar',
										cancelButtonColor: '#fff',
										confirmButtonColor: '#3B3F5C',
										confirmButtonText: 'Aceptar'
									}).then(function(result) {
									    if (result.value === true) {
											window.livewire.emit('emitir-factura', id)
											swal.close()
										} else {
										    window.livewire.emit('print', id)
											swal.close()
										}

									})

								})
						


								window.livewire.on('update-cliente-modal', query_id => {
									swal({
										title: 'CAMBIO DE PRECIOS',
										text: 'HEMOS DETECTADO QUE EL CLIENTE TIENE UNA LISTA DE PRECIOS DIFERENCIAL , ¿DESEA ADECUAR LOS PRECIOS DEL CARRITO A LA LISTA DE PRECIOS DEL CLIENTE?',
										showCancelButton: true,
										cancelButtonText: 'NO',
										cancelButtonColor: '#fff',
										confirmButtonColor: '#3B3F5C',
										confirmButtonText: 'SI'
									}).then(function(result) {
										if (result.value) {
											window.livewire.emit('update-cliente', query_id)
											swal.close()
										}

									})

								})

								var total = $('#suma_totales').val();
								$('#ver_totales').html('Ventas: '+total);


    });
</script>
<script type="text/javascript">
function mostrar()  {

var viewed =	localStorage.getItem("viewed");
var completo_formulario = document.getElementById('completo_formulario').value;


if (completo_formulario != 1) {

if (viewed != 'true') {

$('#ModalFormulario').modal('show');
localStorage.setItem("viewed", 'true');

}

}

}
		 window.onload = mostrar;
</script>
<script type="text/javascript">
	function mostrar_empleador() {
		$('#ModalFormulario').modal('show');
		document.getElementById('ModalFormulario').style.display = 'block';
	}
</script>
@include('livewire.pos.scripts.shortcuts')
@include('livewire.pos.scripts.events')
@include('livewire.pos.scripts.general')
