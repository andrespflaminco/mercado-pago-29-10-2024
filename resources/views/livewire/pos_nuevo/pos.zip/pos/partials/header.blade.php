<div class="d-flex">
  				<div class="mr-auto p-2">
					<div class="page-title">
						<h3>Nueva venta</h3>
						<a hidden href="{{ url('ticket' . '/' . '1103') }}"  target="_blank">Imprimir.</a>

					</div>
				</div>
				<div  class="p-2 d-none d-sm-block">
					<select  wire:model='comprobante' wire:change='MetodoComprobante($event.target.value)' class="form-control">
										<option value="1">No facturar</option>
										<option value="2">Facturar</option>
					</select>
				</div>
				<div  class="p-2 d-none d-sm-block">
					<select  wire:model.lazy='canal_venta' 	class="form-control">
						<option value="Mostrador">Mostrador</option>
						<option value="E-commerce">E-commerce</option>
						<option value="Instragram">Instragram</option>
						<option value="Mercado libre">Mercado libre</option>
					</select>
				</div>
				<div  class="p-2 d-none d-sm-block">
					<div wire:ignore>
						<select  wire:model.lazy='tipo_comprobante'  style="height: calc(1.2em + 1.4rem + 2px) !important;" class="form-control" >
							<option value="" disabled> Tipo de comprobante</option>
							<option value="CF">Consumidor final</option>
							<option value="A">Factura A</option>
							<option value="B">Factura B</option>
							<option value="C">Factura C</option>

						</select>
					</div>
				</div>
  				<div class="p-2 d-none d-sm-block">
					@if($estado_pedido == '')
						<button wire:click="selectEstado()" type="button" style=" width: 130px; margin-top: 3px; margin-bottom: 0 !important; margin-right: 15px; margin-bottom: 0 !important; " class="btn btn-dark" > Estado </button>
					@endif
					
					@if($estado_pedido == 'Pendiente')
						<button wire:click="selectEstado()" type="button" style=" width: 130px; margin-top: 3px; margin-bottom: 0 !important; margin-right: 15px; margin-bottom: 0 !important; " class="btn btn-warning" > Pendiente </button>
					@endif

					@if($estado_pedido == 'En proceso')
						<button wire:click="selectEstado()" type="button" style=" width: 130px; margin-top: 3px; margin-bottom: 0 !important; margin-right: 15px; margin-bottom: 0 !important; " class="btn btn-secondary" > En proceso </button>
					@endif

					@if($estado_pedido == 'Entregado')
						<button type="button" wire:click="selectEstado()" style=" width: 130px; margin-top: 3px; margin-bottom: 0 !important; margin-right: 15px; margin-bottom: 0 !important; " class="btn btn-success" > Entregado </button>
					@endif
				</div>
		    </div>